#!/bin/bash
./lexprog.out $1 $2
